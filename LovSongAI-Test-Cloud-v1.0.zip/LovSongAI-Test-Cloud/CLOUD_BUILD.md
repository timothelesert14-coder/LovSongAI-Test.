# LovSong AI — compilation APK sans PC

Cette version est prévue pour être compilée avec GitHub Actions.

1. Crée un dépôt GitHub et ajoute le contenu de ce dossier.
2. Ouvre l'onglet **Actions** du dépôt.
3. Choisis **Build LovSong AI Test APK** puis **Run workflow**.
4. À la fin du build, ouvre l'exécution terminée.
5. Télécharge l'artifact **LovSongAI-Test-APK**.
6. Décompresse-le sur Android et installe `app-debug.apk`.

Le build utilise Java 17 et Gradle 8.9 dans le cloud. Aucun PC n'est nécessaire.

## Version test

Le mode Démo permet de tester l'interface sans serveur GPU. La génération IA réelle nécessite ensuite l'adresse du backend LovSong AI dans les réglages serveur.
