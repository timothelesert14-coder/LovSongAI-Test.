"""LovSong AI backend v0.8 — direct ACE-Step 1.5 REST integration."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from pathlib import Path
import base64, json, os, re, shutil, subprocess, threading, time, uuid

HOST=os.getenv('LOVSONG_HOST','0.0.0.0'); PORT=int(os.getenv('LOVSONG_PORT','8787'))
PUBLIC_BASE_URL=os.getenv('LOVSONG_PUBLIC_BASE_URL',f'http://127.0.0.1:{PORT}').rstrip('/')
ACE_URL=os.getenv('LOVSONG_ACESTEP_URL','http://127.0.0.1:8001').rstrip('/')
ACE_KEY=os.getenv('LOVSONG_ACESTEP_API_KEY','')
MUSETALK_DIR=Path(os.getenv('LOVSONG_MUSETALK_DIR','')).expanduser() if os.getenv('LOVSONG_MUSETALK_DIR') else None
MUSETALK_PYTHON=os.getenv('LOVSONG_MUSETALK_PYTHON','python')
FFMPEG_PATH=os.getenv('LOVSONG_FFMPEG_PATH','ffmpeg')
MEDIA_DIR=Path(os.getenv('LOVSONG_MEDIA_DIR',Path(__file__).parent/'media')); MEDIA_DIR.mkdir(parents=True,exist_ok=True)
jobs={}; lock=threading.Lock()

def ace_request(path,payload=None,timeout=30):
    body=None if payload is None else json.dumps(payload).encode()
    headers={'Accept':'application/json'}
    if body is not None: headers['Content-Type']='application/json'
    if ACE_KEY: headers['Authorization']=f'Bearer {ACE_KEY}'
    with urlopen(Request(ACE_URL+path,data=body,headers=headers,method='GET' if body is None else 'POST'),timeout=timeout) as r:
        return json.loads(r.read())

def ace_health():
    try:
        x=ace_request('/health',timeout=3); return x.get('code',200)==200
    except Exception: return False

def public_job(j): return {k:v for k,v in j.items() if k not in ('createdAt','payload')}
def set_job(jid,**changes):
    with lock: jobs[jid].update(changes)

def style_prompt(p):
    style=str(p.get('style','R&B Love')); voice=str(p.get('voice','Duo'))
    voice_map={'Féminine':'female lead vocals','Masculine':'male lead vocals','Duo':'romantic male and female duet vocals'}
    return f"romantic love song, {style}, {voice_map.get(voice,voice+' vocals')}, emotional, melodic, polished modern production"

def run_song(jid):
    p=jobs[jid]['payload']
    try:
        set_job(jid,status='processing',progress=10,message='Connexion au moteur musical')
        req={'prompt':style_prompt(p),'lyrics':p['lyrics'],'audio_format':'wav','thinking':True,'use_format':True,'vocal_language':'fr'}
        released=ace_request('/release_task',req,60)
        if released.get('code',200)!=200: raise RuntimeError(released.get('error') or 'ACE-Step a refusé la tâche')
        ace_id=(released.get('data') or {}).get('task_id')
        if not ace_id: raise RuntimeError("ACE-Step n'a retourné aucun task_id")
        set_job(jid,progress=20,message='Chanson en file de génération',engineTaskId=ace_id)
        deadline=time.time()+1800
        while time.time()<deadline:
            q=ace_request('/query_result',{'task_id_list':[ace_id]},30)
            rows=q.get('data') or []
            if not rows: time.sleep(2); continue
            row=rows[0]; status=int(row.get('status',0))
            if status==2: raise RuntimeError(row.get('error') or 'La génération ACE-Step a échoué')
            if status==1:
                result=row.get('result') or '[]'; items=json.loads(result) if isinstance(result,str) else result
                if not items or not items[0].get('file'): raise RuntimeError("ACE-Step n'a retourné aucun fichier audio")
                file_url=items[0]['file']; file_url=file_url if file_url.startswith('http') else ACE_URL+file_url
                out=MEDIA_DIR/f'{jid}.wav'
                headers={};
                if ACE_KEY: headers['Authorization']=f'Bearer {ACE_KEY}'
                with urlopen(Request(file_url,headers=headers),timeout=300) as r: out.write_bytes(r.read())
                if out.stat().st_size==0: raise RuntimeError('Fichier audio vide')
                set_job(jid,status='completed',progress=100,mediaUrl=f'{PUBLIC_BASE_URL}/media/{out.name}',message='Chanson terminée')
                return
            set_job(jid,progress=min(90,jobs[jid].get('progress',20)+2),message='ACE-Step compose et chante…')
            time.sleep(3)
        raise TimeoutError('La génération a dépassé 30 minutes')
    except Exception as e: set_job(jid,status='failed',progress=100,message=str(e))

def run_clip(jid):
    p=jobs[jid]['payload']
    try:
        if not MUSETALK_DIR or not MUSETALK_DIR.exists(): raise RuntimeError('MuseTalk non installé : configure LOVSONG_MUSETALK_DIR')
        song_id=str(p.get('songJobId','')); song=jobs.get(song_id)
        if not song or song.get('status')!='completed': raise RuntimeError('La chanson doit être terminée avant le clip')
        audio=MEDIA_DIR/f'{song_id}.wav'
        if not audio.exists(): raise RuntimeError('Fichier audio de la chanson introuvable')
        raw=p.get('imageBase64') or ''
        if ',' in raw: raw=raw.split(',',1)[1]
        try: image_bytes=base64.b64decode(raw, validate=True)
        except Exception: raise RuntimeError('Photo invalide')
        if not image_bytes or len(image_bytes)>12*1024*1024: raise RuntimeError('Photo vide ou supérieure à 12 Mo')
        work=MEDIA_DIR/f'clip_{jid}'; work.mkdir(exist_ok=True)
        image_path=work/'portrait.jpg'; image_path.write_bytes(image_bytes)
        result_dir=work/'result'; result_dir.mkdir(exist_ok=True)
        config=work/'lovsong.yaml'
        config.write_text(f'task_0:\n  video_path: "{image_path.as_posix()}"\n  audio_path: "{audio.as_posix()}"\n')
        set_job(jid,status='processing',progress=15,message='MuseTalk prépare le visage')
        cmd=[MUSETALK_PYTHON,'-m','scripts.inference','--inference_config',str(config),'--result_dir',str(result_dir),'--unet_model_path','models/musetalkV15/unet.pth','--unet_config','models/musetalkV15/musetalk.json','--version','v15','--ffmpeg_path',FFMPEG_PATH]
        proc=subprocess.Popen(cmd,cwd=MUSETALK_DIR,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        while proc.poll() is None:
            set_job(jid,progress=min(90,jobs[jid].get('progress',15)+2),message='Synchronisation des lèvres avec la chanson…'); time.sleep(3)
        output=(proc.stdout.read() if proc.stdout else '')
        if proc.returncode!=0: raise RuntimeError('MuseTalk a échoué : '+output[-500:])
        videos=sorted(result_dir.rglob('*.mp4'),key=lambda x:x.stat().st_mtime,reverse=True)
        if not videos: raise RuntimeError("MuseTalk n'a produit aucun MP4")
        out=MEDIA_DIR/f'{jid}.mp4'; shutil.copy2(videos[0],out)
        set_job(jid,status='completed',progress=100,mediaUrl=f'{PUBLIC_BASE_URL}/media/{out.name}',message='Clip IA terminé')
    except Exception as e: set_job(jid,status='failed',progress=100,message=str(e))
def launch(jid,kind): threading.Thread(target=run_song if kind=='song' else run_clip,args=(jid,),daemon=True).start()

class Handler(BaseHTTPRequestHandler):
    def send_json(self,code,data):
        raw=json.dumps(data,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def read_json(self):
        try:return json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}')
        except:return {}
    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/health': return self.send_json(200,{'ok':True,'service':'lovsong-ai','aceStepUrl':ACE_URL,'aceStepReachable':ace_health()})
        m=re.fullmatch(r'/v1/(songs|clips)/([\w-]+)',path)
        if m and m.group(2) in jobs:return self.send_json(200,public_job(jobs[m.group(2)]))
        m=re.fullmatch(r'/media/([\w.-]+)',path)
        if m:
            p=MEDIA_DIR/m.group(1)
            if p.exists() and p.is_file():
                raw=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','video/mp4' if p.suffix.lower()=='.mp4' else 'audio/wav'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw); return
        self.send_json(404,{'error':'Not found'})
    def do_POST(self):
        path,p=urlparse(self.path).path,self.read_json()
        if path=='/v1/songs':
            lyrics=str(p.get('lyrics',''))
            if not lyrics or len(lyrics)>4000:return self.send_json(400,{'error':'lyrics must contain 1..4000 characters'})
            kind='song'
        elif path=='/v1/clips':
            if p.get('consentConfirmed') is not True:return self.send_json(400,{'error':'consentConfirmed is required'})
            if not p.get('songJobId') or not p.get('imageBase64'):return self.send_json(400,{'error':'songJobId and imageBase64 are required'})
            kind='clip'
        else:return self.send_json(404,{'error':'Not found'})
        jid=uuid.uuid4().hex; jobs[jid]={'jobId':jid,'kind':kind,'status':'queued','progress':0,'mediaUrl':None,'message':"Génération en file d'attente",'createdAt':time.time(),'payload':p}; launch(jid,kind); self.send_json(202,public_job(jobs[jid]))
    def log_message(self,fmt,*args): pass
if __name__=='__main__':
    print(f'LovSong AI v0.9: http://{HOST}:{PORT} -> ACE-Step {ACE_URL}')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
