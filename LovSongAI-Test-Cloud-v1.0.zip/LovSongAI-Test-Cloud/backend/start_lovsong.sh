#!/usr/bin/env bash
set -euo pipefail
export LOVSONG_ACESTEP_URL="${LOVSONG_ACESTEP_URL:-http://127.0.0.1:8001}"
python3 server.py
