#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-$HOME/MuseTalk}"
if [ ! -d "$DEST/.git" ]; then git clone https://github.com/TMElyralab/MuseTalk.git "$DEST"; fi
cd "$DEST"
python -m pip install -r requirements.txt
python -m pip install --no-cache-dir -U openmim
mim install mmengine
mim install 'mmcv==2.0.1'
mim install 'mmdet==3.1.0'
mim install 'mmpose==1.1.0'
sh ./download_weights.sh
printf '\nMuseTalk installé dans %s\n' "$DEST"
printf 'Avant LovSong: export LOVSONG_MUSETALK_DIR="%s"\n' "$DEST"
