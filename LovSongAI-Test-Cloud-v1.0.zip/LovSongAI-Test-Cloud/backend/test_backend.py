import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import server
assert len('x'*4000)==4000
assert 'romantic' in server.style_prompt({'style':'R&B Love','voice':'Duo'})
print('LovSong backend smoke tests: OK')
