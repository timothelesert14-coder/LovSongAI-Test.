package com.lovsong.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class SongGenerationRequest(val title: String, val lyrics: String, val style: String, val voice: String)
data class ClipGenerationRequest(val songJobId: String, val imageBase64: String, val format: String, val consentConfirmed: Boolean)
data class GenerationJob(
    val jobId: String,
    val status: String = "queued",
    val mediaUrl: String? = null,
    val message: String = "",
    val progress: Int = 0
) {
    val isFinished get() = status == "completed" || status == "failed"
}

object LovSongSession { var latestSongJobId: String? = null }

object AiBackendConfig {
    // URL modifiable depuis l’écran Réglages. Aucune clé fournisseur ne doit être stockée dans l’APK.
    @Volatile var baseUrl: String = ""
    val isConfigured: Boolean get() = baseUrl.startsWith("https://") || baseUrl.startsWith("http://10.0.2.2")
}

class AiBackendClient {
    private val json = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun createSong(input: SongGenerationRequest): Result<GenerationJob> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("title", input.title).put("lyrics", input.lyrics)
                .put("style", input.style).put("voice", input.voice)
            post("/v1/songs", payload)
        }
    }

    suspend fun getSong(jobId: String): Result<GenerationJob> = withContext(Dispatchers.IO) { runCatching { get("/v1/songs/$jobId") } }

    suspend fun generateSong(input: SongGenerationRequest): Result<GenerationJob> {
        val created = createSong(input).getOrElse { return Result.failure(it) }
        LovSongSession.latestSongJobId = created.jobId
        var job = created
        while (!job.isFinished) {
            kotlinx.coroutines.delay(2500)
            job = getSong(created.jobId).getOrElse { return Result.failure(it) }
        }
        return if (job.status == "completed") Result.success(job) else Result.failure(IllegalStateException(job.message))
    }

    suspend fun createClip(input: ClipGenerationRequest): Result<GenerationJob> = withContext(Dispatchers.IO) {
        runCatching {
            require(input.consentConfirmed) { "Autorisation requise" }
            val payload = JSONObject().put("songJobId", input.songJobId).put("imageBase64", input.imageBase64)
                .put("format", input.format).put("consentConfirmed", true)
            post("/v1/clips", payload)
        }
    }

    suspend fun getClip(jobId: String): Result<GenerationJob> = withContext(Dispatchers.IO) {
        runCatching { get("/v1/clips/$jobId") }
    }

    private fun post(path: String, payload: JSONObject): GenerationJob {
        require(AiBackendConfig.isConfigured) { "Serveur IA non configuré" }
        val request = Request.Builder().url(AiBackendConfig.baseUrl.trimEnd('/') + path)
            .post(payload.toString().toRequestBody(json)).build()
        return execute(request)
    }

    private fun get(path: String): GenerationJob {
        require(AiBackendConfig.isConfigured) { "Serveur IA non configuré" }
        return execute(Request.Builder().url(AiBackendConfig.baseUrl.trimEnd('/') + path).get().build())
    }

    private fun execute(request: Request): GenerationJob {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Erreur serveur ${response.code}: ${body.take(180)}")
            val obj = JSONObject(body.ifBlank { "{}" })
            return GenerationJob(
                jobId = obj.optString("jobId").ifBlank { error("jobId manquant") },
                status = obj.optString("status", "queued"),
                mediaUrl = obj.optString("mediaUrl").ifBlank { obj.optString("audioUrl").ifBlank { obj.optString("videoUrl").ifBlank { null } } },
                message = obj.optString("message", "Génération lancée"),
                progress = obj.optInt("progress", 0).coerceIn(0, 100)
            )
        }
    }
}
