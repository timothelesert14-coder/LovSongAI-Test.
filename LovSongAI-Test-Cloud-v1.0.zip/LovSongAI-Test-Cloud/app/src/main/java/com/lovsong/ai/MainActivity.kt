package com.lovsong.ai

import android.os.Bundle
import android.net.Uri
import android.util.Base64
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import coil.compose.AsyncImage
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

private val Bg = Color(0xFF090610)
private val Card = Color(0xFF17101F)
private val Pink = Color(0xFFFF2C8C)
private val Purple = Color(0xFF9C4DFF)
private val Muted = Color(0xFFB9AFC5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LovSongApp() }
    }
}

@Composable
fun LovSongApp() {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        AiBackendConfig.baseUrl = context.getSharedPreferences("lovsong", android.content.Context.MODE_PRIVATE).getString("backend_url", "") ?: ""
    }
    val nav = rememberNavController()
    MaterialTheme(colorScheme = darkColorScheme(primary = Pink, background = Bg, surface = Card)) {
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(nav) }
            composable("create") { CreateSongScreen(nav) }
            composable("story") { PlaceholderScreen(nav, "Notre histoire → Notre chanson", "Raconte votre histoire et LovSong AI préparera une chanson personnalisée.") }
            composable("clip") { ClipAiScreen(nav) }
            composable("library") { LibraryScreen(nav) }
            composable("settings") { SettingsScreen(nav) }
        }
    }
}

@Composable
fun AppBackground(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF13071A), Bg, Color(0xFF100717)))
        ).padding(horizontal = 20.dp),
        content = content
    )
}

@Composable
fun Brand() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("♥♫", color = Pink, fontSize = 42.sp, fontWeight = FontWeight.Black)
        Text("LovSong AI", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
        Text("Crée des chansons qui parlent d’amour", color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen(nav: NavHostController) {
    AppBackground {
        Spacer(Modifier.height(48.dp)); Brand(); Spacer(Modifier.height(30.dp))
        Button(
            onClick = { nav.navigate("create") },
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Pink)
        ) { Text("♥  Créer ma chanson", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(24.dp))
        FeatureCard("♥", "Notre histoire → Notre chanson", "Raconte ton histoire, l’IA crée votre chanson") { nav.navigate("story") }
        FeatureCard("✎", "Écrire mes paroles", "Écris jusqu’à 4 000 caractères") { nav.navigate("create") }
        FeatureCard("▶", "Créer un clip IA", "Fais chanter une photo sur ta chanson") { nav.navigate("clip") }
        FeatureCard("♫", "Mes créations", "Retrouve toutes tes chansons et clips") { nav.navigate("library") }
        FeatureCard("⚙", "Réglages serveur", "Connecte LovSong AI à ton backend") { nav.navigate("settings") }
    }
}

@Composable
fun FeatureCard(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(bottom = 13.dp), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, color = Pink, fontSize = 28.sp, modifier = Modifier.width(48.dp))
            Column { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Spacer(Modifier.height(3.dp)); Text(subtitle, color = Muted, fontSize = 13.sp) }
        }
    }
}

@Composable
fun CreateSongScreen(nav: NavHostController) {
    var title by remember { mutableStateOf("") }
    var lyrics by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("R&B Love") }
    var voice by remember { mutableStateOf("Féminine") }
    var generating by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val backend = remember { AiBackendClient() }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    AppBackground {
        Box(Modifier.fillMaxSize()) {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 34.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { nav.popBackStack() }) { Text("‹ Retour", color = Pink) }
                    Spacer(Modifier.weight(1f)); Text("Créer ma chanson", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp); Spacer(Modifier.weight(1f)); Spacer(Modifier.width(64.dp))
                }
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Spacer(Modifier.height(14.dp))
                    AssistChip(onClick = {}, label = { Text(if (AiBackendConfig.isConfigured) "● Serveur IA" else "● Mode démo") })
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it.take(80) }, modifier = Modifier.fillMaxWidth(), label = { Text("Titre de la chanson") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFF493752)))
                    Spacer(Modifier.height(18.dp)); Text("Mes paroles", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lyrics,
                        onValueChange = { if (it.length <= 4000) lyrics = it },
                        modifier = Modifier.fillMaxWidth().height(230.dp),
                        placeholder = { Text("Écris ici les paroles de ta chanson d’amour…", color = Muted) },
                        supportingText = { Text("${lyrics.length} / 4 000", color = if (lyrics.length >= 3900) Pink else Muted) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFF493752))
                    )
                    Spacer(Modifier.height(18.dp)); Text("Style", color = Color.White, fontWeight = FontWeight.Bold)
                    ChoiceRow(listOf("R&B Love", "Rap Love", "Afro Love"), style) { style = it }
                    Spacer(Modifier.height(14.dp)); Text("Voix", color = Color.White, fontWeight = FontWeight.Bold)
                    ChoiceRow(listOf("Féminine", "Masculine", "Duo"), voice) { voice = it }
                    Spacer(Modifier.height(28.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                if (lyrics.isBlank()) { snackbar.showSnackbar("Ajoute des paroles avant de générer."); return@launch }
                                generating = true; resultMessage = null
                                if (!AiBackendConfig.isConfigured) {
                                    delay(1800)
                                    resultMessage = "Démo terminée ✓ Configure le serveur dans Réglages pour recevoir un vrai fichier audio."
                                } else {
                                    backend.generateSong(SongGenerationRequest(title.ifBlank { "Ma chanson" }, lyrics, style, voice))
                                        .onSuccess {
                                            resultMessage = it.message + (it.mediaUrl?.let { url -> "\nAudio prêt" } ?: "")
                                            it.mediaUrl?.let { url -> saveCreation(context, title.ifBlank { "Ma chanson" }, "song", url) }
                                        }
                                        .onFailure { snackbar.showSnackbar(it.message ?: "Impossible de joindre le serveur IA") }
                                }
                                generating = false
                            }
                        },
                        enabled = !generating,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Pink),
                        shape = RoundedCornerShape(28.dp)
                    ) { Text(if (generating) "Génération…" else "♫  Générer ma chanson", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                    if (generating) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 14.dp), color = Pink)
                    resultMessage?.let { Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text(it, color = Color.White, modifier = Modifier.padding(16.dp)) } }
                    Text("Aucune clé secrète n’est stockée dans l’application. Les fournisseurs IA doivent être appelés par ton serveur.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(10.dp, 14.dp, 10.dp, 30.dp))
                }
            }
            SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Composable
fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        options.forEach { option ->
            FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(option) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple, selectedLabelColor = Color.White, containerColor = Card, labelColor = Muted))
        }
    }
}

@Composable
fun PlaceholderScreen(nav: NavHostController, title: String, text: String) {
    AppBackground {
        Spacer(Modifier.height(36.dp)); TextButton(onClick = { nav.popBackStack() }) { Text("‹ Retour", color = Pink) }
        Spacer(Modifier.height(30.dp)); Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(12.dp)); Text(text, color = Muted, fontSize = 16.sp, lineHeight = 24.sp)
        Spacer(Modifier.height(26.dp)); Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) { Text("Cette partie est prête dans la navigation et sera développée dans la prochaine étape.", color = Color.White, modifier = Modifier.padding(22.dp)) }
    }
}

@Composable
fun ClipAiScreen(nav: NavHostController) {
    val context = LocalContext.current
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var format by remember { mutableStateOf("9:16") }
    var consent by remember { mutableStateOf(false) }
    var generating by remember { mutableStateOf(false) }
    var generated by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        photoUri = uri
        generated = false
    }

    AppBackground {
        Row(Modifier.fillMaxWidth().padding(top = 34.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { nav.popBackStack() }) { Text("‹ Retour", color = Pink) }
            Spacer(Modifier.weight(1f)); Text("Clip IA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp); Spacer(Modifier.weight(1f)); Spacer(Modifier.width(64.dp))
        }
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Spacer(Modifier.height(16.dp))
            Text("Fais chanter une photo", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("Choisis une photo puis le format de ton clip.", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))

            Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (photoUri == null) {
                        Box(Modifier.fillMaxWidth().height(210.dp).background(Color(0xFF24172E), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("♡", color = Pink, fontSize = 50.sp)
                                Text("Aucune photo sélectionnée", color = Muted)
                            }
                        }
                    } else {
                        AsyncImage(model = photoUri, contentDescription = "Photo du clip", modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text(if (photoUri == null) "Ajouter une photo" else "Changer la photo") }
                }
            }

            Spacer(Modifier.height(20.dp)); Text("Format du clip", color = Color.White, fontWeight = FontWeight.Bold)
            ChoiceRow(listOf("9:16", "1:1", "16:9"), format) { format = it }
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = consent, onCheckedChange = { consent = it })
                    Text("Je confirme avoir l’autorisation d’utiliser cette photo pour créer ce clip IA.", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    generating = true; generated = false
                    scope.launch {
                        try {
                            val songId = LovSongSession.latestSongJobId ?: error("Génère d’abord une chanson dans cette session")
                            val bytes = context.contentResolver.openInputStream(photoUri!!)?.use { it.readBytes() } ?: error("Photo illisible")
                            require(bytes.size <= 12 * 1024 * 1024) { "La photo doit faire moins de 12 Mo" }
                            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                            val backend = AiBackendClient()
                            var job = backend.createClip(ClipGenerationRequest(songId, encoded, format, true)).getOrThrow()
                            while (!job.isFinished) { delay(2500); job = backend.getClip(job.jobId).getOrThrow() }
                            if (job.status != "completed") error(job.message)
                            job.mediaUrl?.let { saveCreation(context, "Clip LovSong", "clip", it) }
                            generated = true
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, e.message ?: "Échec du clip IA", android.widget.Toast.LENGTH_LONG).show()
                        } finally { generating = false }
                    }
                },
                enabled = photoUri != null && consent && !generating,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Pink),
                shape = RoundedCornerShape(28.dp)
            ) { Text(if (generating) "Création du clip…" else "▶  Créer mon clip", fontWeight = FontWeight.Bold) }
            if (generating) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 14.dp), color = Pink)
            if (generated) {
                Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Aperçu prêt ✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Clip généré avec synchronisation labiale — format $format.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}


data class SavedCreation(val title: String, val type: String, val url: String)

private fun saveCreation(context: android.content.Context, title: String, type: String, url: String) {
    val prefs = context.getSharedPreferences("lovsong", android.content.Context.MODE_PRIVATE)
    val arr = JSONArray(prefs.getString("creations", "[]"))
    arr.put(JSONObject().put("title", title).put("type", type).put("url", url))
    prefs.edit().putString("creations", arr.toString()).apply()
}

private fun loadCreations(context: android.content.Context): List<SavedCreation> {
    val raw = context.getSharedPreferences("lovsong", android.content.Context.MODE_PRIVATE).getString("creations", "[]") ?: "[]"
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { SavedCreation(it.optString("title"), it.optString("type"), it.optString("url")) } }.reversed()
    }.getOrDefault(emptyList())
}

@Composable
fun SettingsScreen(nav: NavHostController) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("lovsong", android.content.Context.MODE_PRIVATE) }
    var url by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var saved by remember { mutableStateOf(false) }
    AppBackground {
        Spacer(Modifier.height(34.dp)); TextButton(onClick = { nav.popBackStack() }) { Text("‹ Retour", color = Pink) }
        Text("Réglages serveur", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text("Indique l’adresse HTTPS du backend LovSong AI.", color = Muted, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
        OutlinedTextField(url, { url = it.trim() }, modifier = Modifier.fillMaxWidth(), label = { Text("URL du serveur") }, placeholder = { Text("https://api.monsite.fr") })
        Spacer(Modifier.height(16.dp))
        Button(onClick = { prefs.edit().putString("backend_url", url).apply(); AiBackendConfig.baseUrl = url; saved = true }, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer") }
        if (saved) Text("Serveur enregistré ✓", color = Color.White, modifier = Modifier.padding(top = 14.dp))
        Text("Pour l’émulateur Android, http://10.0.2.2 peut être utilisé en développement local. En production, utilise HTTPS.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
fun LibraryScreen(nav: NavHostController) {
    val context = LocalContext.current
    var items by remember { mutableStateOf(loadCreations(context)) }
    AppBackground {
        Spacer(Modifier.height(34.dp)); TextButton(onClick = { nav.popBackStack() }) { Text("‹ Retour", color = Pink) }
        Text("Mes créations", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        if (items.isEmpty()) Text("Tes chansons et clips terminés apparaîtront ici.", color = Muted)
        Column(Modifier.verticalScroll(rememberScrollState())) {
            items.forEach { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(if (item.type == "clip") "Clip IA" else "Chanson", color = Muted, fontSize = 12.sp)
                        }
                        TextButton(onClick = {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url))) }
                        }) { Text("Ouvrir", color = Pink) }
                    }
                }
            }
            if (items.isNotEmpty()) TextButton(onClick = { context.getSharedPreferences("lovsong", android.content.Context.MODE_PRIVATE).edit().remove("creations").apply(); items = emptyList() }) { Text("Effacer la bibliothèque", color = Muted) }
        }
    }
}
