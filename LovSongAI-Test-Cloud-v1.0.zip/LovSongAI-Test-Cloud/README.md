# LovSong AI v0.9

Prototype Android (Kotlin + Jetpack Compose) + backend Python.

## Musique réelle
Le backend se connecte à l'API REST ACE-Step 1.5 via `LOVSONG_ACESTEP_URL` (par défaut `http://127.0.0.1:8001`). L'app envoie jusqu'à 4 000 caractères de paroles, attend le job, puis reçoit le WAV.

## Clip IA réel (MuseTalk 1.5)
Après une chanson terminée, l'app permet de choisir une photo et exige la confirmation d'autorisation. La photo (12 Mo max) est envoyée au backend. Le backend lance MuseTalk 1.5 avec la photo et le WAV, puis expose le MP4 final.

Installation Linux de MuseTalk :
```bash
cd backend
./install_musetalk.sh ~/MuseTalk
export LOVSONG_MUSETALK_DIR="$HOME/MuseTalk"
export LOVSONG_MUSETALK_PYTHON=python
export LOVSONG_FFMPEG_PATH=ffmpeg
```
MuseTalk recommande Python 3.10 et un environnement CUDA compatible. Son installation officielle doit être suivie si le script ne correspond pas au GPU de la machine.

## Démarrer LovSong
```bash
export LOVSONG_PUBLIC_BASE_URL="https://ton-domaine.example"
export LOVSONG_ACESTEP_URL="http://127.0.0.1:8001"
python backend/server.py
```
Puis renseigner l'URL HTTPS du backend dans `AiBackendConfig.BASE_URL` avant de compiler l'app Android.

## Important
Les modèles sont gratuits/open source, mais une génération publique nécessite du calcul GPU et donc un hébergement. La v0.9 ne contient aucune clé fournisseur dans l'APK. Les clips ne peuvent être lancés que si l'utilisateur confirme qu'il a l'autorisation d'utiliser la photo.
